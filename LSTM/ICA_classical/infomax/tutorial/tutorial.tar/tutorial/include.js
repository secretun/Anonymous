<script language="JavaScript"><!--

function openhelp(fnc){ // open the help window
var mlwin=window.open(fnc+".help",'fnchelp',
 'width=680,height=390,scrollbars=yes,resizable');
  mlwin.focus();
  mlwin.bgcolor = "#ffffe5";
}
function openhelpurl(url){ // open the help window to an exact url
                           //   - for example, 'my.help#name'
var mlwin=window.open(url,'fnchelp',
 'width=680,height=380,scrollbars=yes,resizable');
  mlwin.bgcolor = "#ffffe5";
  mlwin.focus();
}
function openplot(plt){ // open the expanded plot window - show .jpg plot
var tpwin=window.open(plt + '.jpg','tpwind',
 'bgcolor="#fffff6",width=680,height=380,scrollbars=yes,resizable,title="'+plt+'() - ICA/EEG toolbox"');
  tpwin.focus();
}
function opengifplot(plt){ // open the expanded plot window - show .gif plot
var tpwin=window.open(plt + ".gif",'tpwind',
 'bgcolor="#fffff6",width=680,height=380,scrollbars=yes,resizable,title="'+plt+'() - ICA/EEG toolbox"');
    tpwin.focus();
}
function openoutwindow(){ // open the outline window
var outwin=window.open("outline.help",'outline',
 'width=330,height=380,scrollbars=yes,resizable');
  outwin.bgColor = "#ffffe5";
  outwin.focus();
}
function openhelpplot(plt,url){ // show plot example from help window 
                                //  - specify .jpg or .gif in plt arg
var tpwin=window.open(plt,'tpwind',
 'bgcolor="#fffff6",width=680,height=380,scrollbars=yes,resizable,title="'+plt+'() - ICA/EEG toolbox"');
  self.opener.location=url;
  self.opener.focus();
}

//-->
</script>
